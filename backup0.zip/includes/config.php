<?php
  define( 'DB_HOST', 'localhost' );          // Set database host
  define( 'DB_USER', 'id8442907_dev' );             // Set database user
  define( 'DB_PASS', 'contraizad' );             // Set database password
  define( 'DB_NAME', 'id8442907_data' );        // Set database name
?>
